import React, { useState } from 'react';
import { 
  Hammer, 
  Download, 
  Upload, 
  CheckCircle, 
  AlertTriangle, 
  Play, 
  FileText, 
  ArrowRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useToast } from '../context/ToastContext';
import { apiClient } from '../services/api';
import { ConnectionPanel } from '../components/ConnectionPanel';
// FIX: Import the function that actually exists in your certParser.ts
import { parseCertificateUrl } from '../utils/certParser';

// --- Types ---

type LBType = 'http' | 'https_auto' | 'https_custom';
type DomainStrategy = 'single' | 'multi';

interface CSVRow {
  name: string;
  namespace: string;
  domains: string[]; // Parsed from CSV
  origin_pool: string;
  origin_pool_namespace: string;
  cert_name?: string; // For Custom Cert (found or provided)
  cert_namespace?: string; // For Custom Cert
  status: 'pending' | 'processing' | 'success' | 'error';
  message?: string;
  result?: {
    vip?: string;
    cname?: string;
    acme_cname?: string;
  };
}

interface ParsedCert {
  name: string;
  namespace: string;
  cn: string;
  sans: string[];
  validTo: Date;
}

// --- Helper Functions ---

const downloadCSV = (content: string, filename: string) => {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export function HttpLbForge() {
  const { credentials } = useApp();
  const { showToast } = useToast();

  // State
  const [activeStep, setActiveStep] = useState<number>(1);
  const [lbType, setLbType] = useState<LBType>('http');
  const [domainStrategy, setDomainStrategy] = useState<DomainStrategy>('single');
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [csvContent, setCsvContent] = useState<string>('');
  const [parsedRows, setParsedRows] = useState<CSVRow[]>([]);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [availableCerts, setAvailableCerts] = useState<ParsedCert[]>([]);
  const [isFetchingCerts, setIsFetchingCerts] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // --- Step 1: Template Generation ---

  const generateTemplate = () => {
    let headers = ['Name', 'Namespace', 'Origin Pool', 'Origin Pool Namespace'];
    
    if (domainStrategy === 'single') {
      headers.push('Domain');
    } else {
      headers.push('Domains (comma separated)');
    }

    const csv = headers.join(',') + '\n' + 
      (domainStrategy === 'single' 
        ? 'my-lb-01,documentation,my-pool,documentation,app.example.com' 
        : 'my-lb-01,documentation,my-pool,documentation,"app.example.com,api.example.com"');

    downloadCSV(csv, `http_lb_template_${lbType}_${domainStrategy}.csv`);
    showToast('Template downloaded successfully', 'success');
  };

  // --- Step 2: Upload & Validation ---

  const fetchCertificates = async (namespace: string) => {
    try {
      setIsFetchingCerts(true);
      const response = await apiClient.getCertificates(namespace);
      
      const parsed: ParsedCert[] = [];
      
      for (const item of response.items) {
          // FIX: Use the 'certificate_url' field which contains the cert data string
          // your parseCertificateUrl function expects a string.
          if (item.spec?.certificate_url) {
              const certDetails = parseCertificateUrl(item.spec.certificate_url);
              
              if (certDetails) {
                  parsed.push({
                      name: item.metadata.name,
                      namespace: item.metadata.namespace,
                      // Access properties based on your ParsedCertificate interface
                      cn: certDetails.subject.commonName, 
                      sans: certDetails.sans,
                      validTo: certDetails.validTo // Type is Date in your interface
                  });
              }
          }
      }
      return parsed;
    } catch (error) {
      console.error("Failed to fetch certs:", error);
      showToast(`Failed to fetch certificates from ${namespace}`, 'error');
      return [];
    } finally {
      setIsFetchingCerts(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const text = event.target?.result as string;
      setCsvContent(text);
      await processCSV(text);
    };
    reader.readAsText(file);
  };

  const processCSV = async (text: string) => {
    const lines = text.split('\n');
    const headers = lines[0].split(',').map(h => h.trim());
    
    // Detect indexes
    const nameIdx = headers.findIndex(h => h.toLowerCase() === 'name');
    const nsIdx = headers.findIndex(h => h.toLowerCase() === 'namespace');
    const poolIdx = headers.findIndex(h => h.toLowerCase() === 'origin pool');
    const poolNsIdx = headers.findIndex(h => h.toLowerCase() === 'origin pool namespace');
    const domainIdx = headers.findIndex(h => h.toLowerCase().startsWith('domain'));

    if (nameIdx === -1 || nsIdx === -1 || poolIdx === -1 || domainIdx === -1) {
      showToast('Invalid CSV format. Missing required columns.', 'error');
      return;
    }

    const rows: CSVRow[] = [];
    
    // We need to fetch certs if active mode is Custom Cert
    // Optimization: Group by namespace to fetch certs once per namespace
    let certsCache: Record<string, ParsedCert[]> = {};

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      
      // Simple CSV split handling quotes (basic implementation)
      // For robust parsing, use a library, but here we assume simple CSV
      const cols = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/).map(c => c.trim().replace(/^"|"$/g, ''));
      
      const ns = cols[nsIdx];
      const domainsRaw = cols[domainIdx];
      const domains = domainStrategy === 'single' ? [domainsRaw] : domainsRaw.split(',').map(d => d.trim());

      let certName = undefined;
      let certNs = undefined;
      let status: CSVRow['status'] = 'pending';
      let message = '';

      if (lbType === 'https_custom') {
        if (!certsCache[ns]) {
             certsCache[ns] = await fetchCertificates(ns);
             // Also fetch from 'shared' namespace as certs often live there
             if (ns !== 'shared') {
                 const sharedCerts = await fetchCertificates('shared');
                 certsCache[ns] = [...certsCache[ns], ...sharedCerts];
             }
        }

        // Find match
        // Logic: Find a cert that covers ALL domains in the list? Or just the first?
        // Usually 1 LB = 1 Cert. So the cert must cover all domains or we pick the best one.
        // Let's try to find a cert that matches the first domain, and warn if others don't match.
        
        const targetDomain = domains[0];
        const match = certsCache[ns].find(c => {
             // Check CN
             if (c.cn === targetDomain) return true;
             // Check SANs
             if (c.sans.includes(targetDomain)) return true;
             // Check Wildcard
             if (c.cn.startsWith('*.')) {
                 const base = c.cn.slice(2);
                 if (targetDomain.endsWith(base) && targetDomain.split('.').length === base.split('.').length + 1) return true;
             }
             // Check SAN Wildcards
             return c.sans.some(s => {
                 if (s.startsWith('*.')) {
                     const base = s.slice(2);
                     return targetDomain.endsWith(base) && targetDomain.split('.').length === base.split('.').length + 1;
                 }
                 return false;
             });
        });

        if (match) {
            certName = match.name;
            certNs = match.namespace;
            message = `Matched cert: ${match.name} (${match.cn})`;
        } else {
            status = 'error';
            message = 'No matching certificate found';
        }
      }

      rows.push({
        name: cols[nameIdx],
        namespace: ns,
        origin_pool: cols[poolIdx],
        origin_pool_namespace: cols[poolNsIdx] !== undefined ? cols[poolNsIdx] : ns, // Default to LB ns if missing
        domains,
        cert_name: certName,
        cert_namespace: certNs,
        status,
        message
      });
    }

    setAvailableCerts(Object.values(certsCache).flat());
    setParsedRows(rows);
  };

  // --- Step 3: Execution ---

  const executeBulkCreation = async () => {
    setIsProcessing(true);
    const newRows = [...parsedRows];

    for (let i = 0; i < newRows.length; i++) {
      const row = newRows[i];
      if (row.status === 'error') continue; // Skip bad rows

      row.status = 'processing';
      setParsedRows([...newRows]);

      try {
        const payload: any = {
          metadata: {
            name: row.name,
            namespace: row.namespace,
            disable: false
          },
          spec: {
            domains: row.domains,
            default_route_pools: [
              {
                pool: {
                  name: row.origin_pool,
                  namespace: row.origin_pool_namespace,
                  tenant: credentials?.tenant
                },
                weight: 1,
                priority: 1
              }
            ],
            // Default settings
            advertise_on_public_default_vip: {},
            disable_waf: {},
            disable_bot_defense: {},
            disable_api_discovery: {},
            round_robin: {}
          }
        };

        // Type Specific Config
        if (lbType === 'https_auto') {
          payload.spec.https_auto_cert = {
            http_redirect: true,
            add_hsts: true,
            tls_config: {
              default_security: {}
            },
            no_mtls: {}
          };
        } else if (lbType === 'https_custom') {
           payload.spec.https = {
             http_redirect: true,
             add_hsts: true,
             tls_cert_params: {
                certificates: [
                    {
                        name: row.cert_name,
                        namespace: row.cert_namespace,
                        tenant: credentials?.tenant
                    }
                ],
                no_mtls: {} // Assuming one-way TLS for public web
             },
             tls_config: {
                 default_security: {}
             }
           };
        } else {
           // HTTP
           payload.spec.http = {
               dns_volterra_managed: false, // Usually false for pure HTTP on port 80 if not auto-cert?
               port: 80
           };
        }

        await apiClient.createHttpLoadBalancer(row.namespace, payload);
        
        row.status = 'success';
        row.message = 'Created successfully';
      } catch (err: any) {
        row.status = 'error';
        row.message = err.message || 'Creation failed';
      }

      setParsedRows([...newRows]);
    }

    setIsProcessing(false);
    setActiveStep(4);
    showToast('Bulk creation completed', 'success');
  };

  // --- Step 4: Report ---

  const generateReport = async () => {
     // Fetch fresh data for successful LBs to get VIP/CNAME
     const reportRows = ['Name,Namespace,Type,Domains,VIP,CNAME,Status,Message'];

     for (const row of parsedRows) {
        let vip = 'N/A';
        let cname = 'N/A';
        
        if (row.status === 'success') {
            try {
                // Computed guess for default CNAME
                cname = `${row.name}.${row.namespace}.app.ves.io`; 
            } catch (e) {
                // Ignore fetch error
            }
        }

        reportRows.push(
            `${row.name},${row.namespace},${lbType},"${row.domains.join(';')}",${vip},${cname},${row.status},${row.message}`
        );
     }

     downloadCSV(reportRows.join('\n'), `http_lb_forge_report_${new Date().toISOString().slice(0,10)}.csv`);
  };

  // --- UI Components ---

  const StepIndicator = () => (
    <div className="flex items-center justify-center mb-8">
      {[1, 2, 3, 4].map((step) => (
        <React.Fragment key={step}>
          <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 
            ${activeStep >= step 
              ? 'bg-blue-600 border-blue-600 text-white' 
              : 'border-slate-300 text-slate-400'}`}>
            {activeStep > step ? <CheckCircle className="w-6 h-6" /> : step}
          </div>
          {step < 4 && (
            <div className={`w-16 h-1 ${activeStep > step ? 'bg-blue-600' : 'bg-slate-200'}`} />
          )}
        </React.Fragment>
      ))}
    </div>
  );

  if (!credentials) return <ConnectionPanel />;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 flex items-center gap-3">
          <Hammer className="text-blue-600" />
          HTTP LB Forge
        </h1>
        <p className="text-slate-600 mt-2">
          Automated bulk creation of HTTP/HTTPS Load Balancers with intelligent certificate matching.
        </p>
      </div>

      <StepIndicator />

      {/* STEP 1: Configuration & Template */}
      {activeStep === 1 && (
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
          <h2 className="text-xl font-semibold mb-4 text-slate-800">1. Configuration & Template</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Load Balancer Type</label>
              <select 
                value={lbType}
                onChange={(e) => setLbType(e.target.value as LBType)}
                className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="http">HTTP (Port 80)</option>
                <option value="https_auto">HTTPS with Auto Certificate</option>
                <option value="https_custom">HTTPS with Custom Certificate</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Domain Strategy</label>
              <select 
                value={domainStrategy}
                onChange={(e) => setDomainStrategy(e.target.value as DomainStrategy)}
                className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="single">Single Domain per LB</option>
                <option value="multi">Multiple Domains per LB</option>
              </select>
            </div>
          </div>

          <div className="flex justify-between items-center border-t border-slate-100 pt-6">
             <button 
                onClick={generateTemplate}
                className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition-colors"
             >
                <Download className="w-4 h-4" />
                Download Template CSV
             </button>
             
             <button 
                onClick={() => setActiveStep(2)}
                className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors shadow-md"
             >
                Next: Upload Data
                <ArrowRight className="w-4 h-4" />
             </button>
          </div>
        </div>
      )}

      {/* STEP 2: Upload & Review */}
      {activeStep === 2 && (
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
           <h2 className="text-xl font-semibold mb-4 text-slate-800">2. Upload & Verify Data</h2>
           
           <div className="mb-6">
             <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors bg-slate-50">
               <input 
                 type="file" 
                 accept=".csv"
                 onChange={handleFileUpload}
                 className="hidden" 
                 id="csv-upload"
               />
               <label htmlFor="csv-upload" className="cursor-pointer flex flex-col items-center">
                 <Upload className="w-12 h-12 text-slate-400 mb-2" />
                 <span className="text-sm text-slate-600 font-medium">Click to upload your filled CSV file</span>
               </label>
             </div>
           </div>

           {parsedRows.length > 0 && (
             <div className="mb-6">
               <h3 className="text-sm font-semibold text-slate-700 mb-2">
                 Preview ({parsedRows.length} items)
                 {lbType === 'https_custom' && (
                    <span className="ml-2 text-xs font-normal text-slate-500">
                        {isFetchingCerts ? '(Searching certificates...)' : '(Certificates matched)'}
                    </span>
                 )}
               </h3>
               <div className="overflow-x-auto border border-slate-200 rounded-md max-h-64">
                 <table className="min-w-full divide-y divide-slate-200">
                   <thead className="bg-slate-50">
                     <tr>
                       <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase">Name</th>
                       <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase">Namespace</th>
                       <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase">Domains</th>
                       <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase">Origin Pool</th>
                       {lbType === 'https_custom' && (
                         <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase">Cert Status</th>
                       )}
                     </tr>
                   </thead>
                   <tbody className="bg-white divide-y divide-slate-200">
                     {parsedRows.map((row, idx) => (
                       <tr key={idx}>
                         <td className="px-4 py-2 text-sm text-slate-900">{row.name}</td>
                         <td className="px-4 py-2 text-sm text-slate-600">{row.namespace}</td>
                         <td className="px-4 py-2 text-sm text-slate-600">{row.domains.join(', ')}</td>
                         <td className="px-4 py-2 text-sm text-slate-600">{row.origin_pool}</td>
                         {lbType === 'https_custom' && (
                           <td className="px-4 py-2 text-sm">
                             {row.status === 'error' ? (
                               <span className="text-red-600 flex items-center gap-1">
                                 <AlertTriangle className="w-3 h-3" /> Not Found
                               </span>
                             ) : (
                               <span className="text-green-600 flex items-center gap-1">
                                 <CheckCircle className="w-3 h-3" /> {row.cert_name}
                               </span>
                             )}
                           </td>
                         )}
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
             </div>
           )}

           <div className="flex justify-between items-center border-t border-slate-100 pt-6">
             <button 
                onClick={() => {
                    setActiveStep(1);
                    setParsedRows([]);
                    setCsvContent('');
                }}
                className="text-slate-500 hover:text-slate-700"
             >
                Back
             </button>
             
             <button 
                onClick={() => setActiveStep(3)}
                disabled={parsedRows.length === 0 || isFetchingCerts}
                className={`flex items-center gap-2 px-6 py-2 rounded-md text-white shadow-md transition-colors
                    ${parsedRows.length === 0 || isFetchingCerts ? 'bg-slate-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700'}`}
             >
                Next: Create Load Balancers
                <ArrowRight className="w-4 h-4" />
             </button>
          </div>
        </div>
      )}

      {/* STEP 3: Execution */}
      {activeStep === 3 && (
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
          <h2 className="text-xl font-semibold mb-4 text-slate-800">3. Creating Load Balancers</h2>
          
          <div className="text-center py-8">
            {!isProcessing && parsedRows.some(r => r.status === 'pending') ? (
                <div>
                    <p className="text-slate-600 mb-6">
                        Ready to create {parsedRows.filter(r => r.status !== 'error').length} Load Balancers.
                    </p>
                    <button 
                        onClick={executeBulkCreation}
                        className="px-8 py-3 bg-green-600 text-white rounded-full text-lg font-medium hover:bg-green-700 shadow-lg flex items-center gap-2 mx-auto"
                    >
                        <Play className="w-5 h-5" />
                        Start Creation Process
                    </button>
                </div>
            ) : (
                <div className="w-full">
                    {/* Progress Bar */}
                    <div className="w-full bg-slate-200 rounded-full h-4 mb-6 overflow-hidden">
                        <div 
                            className="bg-blue-600 h-4 transition-all duration-300"
                            style={{ width: `${(parsedRows.filter(r => r.status === 'success' || r.status === 'error').length / parsedRows.length) * 100}%` }}
                        ></div>
                    </div>
                    
                    {/* Live Log */}
                    <div className="bg-slate-900 text-slate-300 p-4 rounded-md h-64 overflow-y-auto text-left font-mono text-sm">
                        {parsedRows.map((row, idx) => (
                            <div key={idx} className={`mb-1 ${
                                row.status === 'success' ? 'text-green-400' : 
                                row.status === 'error' ? 'text-red-400' : 
                                row.status === 'processing' ? 'text-blue-400' : 'text-slate-500'
                            }`}>
                                [{row.status.toUpperCase()}] {row.name}: {row.message || 'Waiting...'}
                            </div>
                        ))}
                    </div>
                </div>
            )}
          </div>
        </div>
      )}

      {/* STEP 4: Report */}
      {activeStep === 4 && (
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6 text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Process Completed</h2>
          <p className="text-slate-600 mb-8">
            Successfully processed {parsedRows.length} items. 
            ({parsedRows.filter(r => r.status === 'success').length} Created, {parsedRows.filter(r => r.status === 'error').length} Failed)
          </p>

          <div className="flex justify-center gap-4">
             <button 
                onClick={() => {
                    setActiveStep(1);
                    setParsedRows([]);
                    setCsvContent('');
                }}
                className="px-6 py-2 border border-slate-300 text-slate-700 rounded-md hover:bg-slate-50"
             >
                Start New Batch
             </button>
             <button 
                onClick={generateReport}
                className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 shadow-md flex items-center gap-2"
             >
                <FileText className="w-4 h-4" />
                Download Final Report
             </button>
          </div>
        </div>
      )}

    </div>
  );
};